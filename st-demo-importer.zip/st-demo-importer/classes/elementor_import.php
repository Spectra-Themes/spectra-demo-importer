<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

class StElementor_Import {

    private $whizzie_instance;

    public function __construct($whizzie_instance) {
        $this->whizzie_instance = $whizzie_instance;
    }
    
    public function st_demo_importer_setup_elementor() {

        $st_themes = $this->whizzie_instance->get_st_themes();
        $arrayJson = array();
        if( $st_themes['status'] == 200 && !empty($st_themes['data']) ) {
            
            $st_themes_data = $st_themes['data'];
            foreach ( $st_themes_data as $single_theme ) {
                $arrayJson[$single_theme->theme_text_domain] = array(
                    'title' => $single_theme->theme_page_title,
                    'url' => $single_theme->theme_url
                );
            }
        }

        $my_theme_txd = wp_get_theme();
        $get_textdomain = $my_theme_txd->get('TextDomain');

        $pages_arr = array();
        if (array_key_exists($get_textdomain, $arrayJson)) {
            $getpreth = $arrayJson[$get_textdomain];
            array_push($pages_arr, array(
                'title' => $getpreth['title'],
                'ishome' => 1,
                'type' => '',
                'post_type' => 'page',
                'url' => $getpreth['url'],
            ));
            
            
            if(defined('IS_ST_PREMIUM')){
                    
                if (file_exists(get_template_directory() . '/inc/page.json')) {
                    $json_url = get_template_directory_uri() . '/inc/page.json';
                    $response = wp_remote_get($json_url);
                
                    if (!is_wp_error($response) && $response['response']['code'] == 200) {
                        $inner_page_json = wp_remote_retrieve_body($response);
                        $inner_page_json_decoded = json_decode($inner_page_json, true);
                
                        if ($inner_page_json_decoded !== null) {
                            foreach ($inner_page_json_decoded as $page) {
                                array_push($pages_arr, array(
                                    'type' => isset($page['type']) ? $page['type'] : '',
                                    'title' => $page['name'],
                                    'ishome' => 0,
                                    'post_type' => $page['posttype'],
                                    'url' => $page['source'],
                                ));
                            }
                        } 
                    }
                }                
            }
        } else {
            array_push($pages_arr, array(
                'title' => 'Spectra Business',
                'type' => '',
                'ishome' => 1,
                'post_type' => 'page',
                'url' => ST_THEMES_HOME_URL . "/demo/all-json/spectra-business/spectra-business.json",
            ));
        }

        foreach ($pages_arr as $page) {
            $elementor_template_data = $page['url'];
            $elementor_template_data_title = $page['title'];
            $ishome = $page['ishome'];
            $post_type = $page['post_type'];
            $type = $page['type'];
            $this->import_inner_pages_data($elementor_template_data, $elementor_template_data_title, $ishome,$post_type,$type);
        }

        // call theme function start //
        $setup_widgets_function = str_replace( '-', '_', $get_textdomain ) . '_setup_widgets';
        if ( class_exists('Whizzie') && method_exists( 'Whizzie', $setup_widgets_function ) ) {
            Whizzie::$setup_widgets_function();
        }
        // call theme function end //

        wp_send_json(array(
            'permalink' => site_url(),
            'edit_post_link' => admin_url('post.php?post=' . $home_id . '&action=elementor')
        ));
    }

    public function random_string($length) {
        
        $key = '';
        $keys = array_merge(range(0, 9), range('a', 'z'));
        for ($i = 0;$i < $length;$i++) {
            $key.= $keys[array_rand($keys) ];
        }
        return $key;
    }

    public function import_inner_pages_data($elementor_template_data, $elementor_template_data_title, $ishome,$post_type,$type){

        $response = wp_remote_get($elementor_template_data);

        if (is_wp_error($response)) {
            // Handle error
            return;
        }
        
        $elementor_template_data_json = wp_remote_retrieve_body($response);

        // Upload the file first
        $upload_dir = wp_upload_dir();
        $filename = $this->random_string(25) . '.json';
        $file = trailingslashit($upload_dir['path']) . $filename;

        // Initialize WP_Filesystem
        if ( ! function_exists( 'WP_Filesystem' ) ) {
            require_once ABSPATH . '/wp-admin/includes/file.php';
        }
    
        WP_Filesystem();
    
        global $wp_filesystem;
    
        if ( ! $wp_filesystem ) {
            // Failed to initialize WP_Filesystem, handle error
            return;
        }

        $write_result = $wp_filesystem->put_contents($file, $elementor_template_data_json, FS_CHMOD_FILE);

        if ( ! $write_result ) {
            // Failed to write file, handle error
            return;
        }

        $json_path = $upload_dir['path'] . '/' . $filename;
        $json_url = $upload_dir['url'] . '/' . $filename;
        $elementor_home_data = $this->get_elementor_theme_data($json_url, $json_path);

        $page_title = $elementor_template_data_title;
        $home_page = array(
            'post_type' => $post_type, 
            'post_title' => $page_title, 
            'post_content' => $elementor_home_data['elementor_content'], 
            'post_status' => 'publish', 
            'post_author' => 1, 
            'meta_input' => $elementor_home_data['elementor_content_meta']
        );
        $home_id = wp_insert_post($home_page);
        $get_author = wp_get_theme();
        $theme_author = $get_author->display( 'Author', FALSE );
        if( $theme_author == 'SpectraThemes'){
            update_post_meta( $home_id, '_wp_page_template', 'templates/template-page-builders.php' );
        }

        if($post_type == 'elementskit_template'){
            update_post_meta( $home_id, '_wp_page_template', 'elementor_canvas' );
            update_post_meta( $home_id, 'elementskit_template_activation', 'yes' );
            update_post_meta( $home_id, 'elementskit_template_type', $type );
            update_post_meta( $home_id, 'elementskit_template_condition_a', 'entire_site' );
        } else {
            if ($ishome !== 0) {
                update_option('page_on_front', $home_id);
                update_option('show_on_front', $post_type);

                $my_theme_txd = wp_get_theme();
                $get_textdomain = $my_theme_txd->get('TextDomain');
                $api_url = SEDI_ADMIN_CUSTOM_ENDPOINT . 'get_spectra_custom_api_two_details_dt';
                $options = ['headers' => ['Content-Type' => 'application/json', ]];
                $response = wp_remote_get($api_url, $options);
                $json = json_decode( $response['body'] );

                $sedi_free_text_domain = array();

                if ($json->code == 200) {
                    foreach ($json->data as $value) {

                        $get_all_domains = $value->theme_domain_array;
                        array_push($sedi_free_text_domain, $get_all_domains);
                    }
                }
                
                if(in_array($get_textdomain,  $sedi_free_text_domain)) {
                    add_post_meta( $home_id, '_wp_page_template', 'home-page-template.php' );
                }
            }
        }
    }

    public function get_elementor_theme_data($json_url, $json_path) {
    
        // Mime a supported document type.
        $elementor_plugin = \Elementor\Plugin::$instance;
        $elementor_plugin->documents->register_document_type('not-supported', \Elementor\Modules\Library\Documents\Page::get_class_full_name());
        $template = $json_path;
        $name = '';
        $_FILES['file']['tmp_name'] = $template;
        $elementor = new \Elementor\TemplateLibrary\Source_Local;
        $elementor->import_template($name, $template);
        wp_delete_file($json_path);

        $args = array('post_type' => 'elementor_library','nopaging' => true,'posts_per_page' => '1','orderby' => 'date','order' => 'DESC');
        add_filter('posts_where', array($this, 'custom_posts_where'));
        $query = new \WP_Query($args);
        remove_filter('posts_where', array($this, 'custom_posts_where'));
    
        $last_template_added = $query->posts[0];
        //get template id
        $template_id = $last_template_added->ID;
        wp_reset_query();
        wp_reset_postdata();
        //page content
        $page_content = $last_template_added->post_content;
        //meta fields
        $elementor_data_meta = get_post_meta($template_id, '_elementor_data');
        $elementor_ver_meta = get_post_meta($template_id, '_elementor_version');
        $elementor_edit_mode_meta = get_post_meta($template_id, '_elementor_edit_mode');
        $elementor_css_meta = get_post_meta($template_id, '_elementor_css');
        $elementor_metas = array('_elementor_data' => !empty($elementor_data_meta[0]) ? wp_slash($elementor_data_meta[0]) : '', '_elementor_version' => !empty($elementor_ver_meta[0]) ? $elementor_ver_meta[0] : '', '_elementor_edit_mode' => !empty($elementor_edit_mode_meta[0]) ? $elementor_edit_mode_meta[0] : '', '_elementor_css' => $elementor_css_meta,);
        $elementor_json = array('elementor_content' => $page_content, 'elementor_content_meta' => $elementor_metas);
        return $elementor_json;
    }

    public function custom_posts_where($where) {
        return $where;
    }
}