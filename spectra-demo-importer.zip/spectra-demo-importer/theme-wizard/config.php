<?php
/**
 * Settings for theme wizard
 *
 * @package Whizzie
 * @author Catapult Themes
 * @since 1.0.0
 */

/**
 * Define constants
 **/
if ( ! defined( 'SPECTRA_DEMO_IMPORTER_WHIZZIE_DIR' ) ) {
	define( 'SPECTRA_DEMO_IMPORTER_WHIZZIE_DIR', dirname( __FILE__ ) );
}

// Classes for separate codes
require_once SEDI_DIR . 'classes/script_enqueuer.php';
require_once SEDI_DIR . 'classes/setup_plugins.php';
require_once SEDI_DIR . 'classes/elementor_import.php';
require_once SEDI_DIR . 'classes/activation.php';
require_once SEDI_DIR . 'classes/steps.php';

// Load the Whizzie class and other dependencies
require trailingslashit( SPECTRA_DEMO_IMPORTER_WHIZZIE_DIR ) . 'spectra_demo_importer_whizzie.php';

/**
 * This kicks off the wizard
 **/
if( class_exists( 'Spectra_Demo_Importer_ThemeWhizzie' ) ) {
	$Spectra_Demo_Importer_ThemeWhizzie = new Spectra_Demo_Importer_ThemeWhizzie();
}
