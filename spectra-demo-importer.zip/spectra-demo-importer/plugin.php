<?php
/**
*  Plugin Name:       Spectra Demo Importer
*  Plugin URI:        https://spectrathemes.com/plugins/
*  Description:       Spectra Demo Importer is a powerful WordPress plugin designed to seamlessly integrate with Elementor, the leading page builder for WordPress. With Spectra Demo Importer, you can effortlessly import stunning pre-designed themes and templates directly into your Elementor-powered website, saving you time and effort in building your website from scratch.
*  Version:           0.0.1
*  Requires at least: 5.2
*  Requires PHP:      7.4
*  Author:            spectrathemes
*  Author URI:        https://www.spectrathemes.com/
*  License:           GPL v2 or later
*  License URI:       https://www.gnu.org/licenses/gpl-2.0.html
*  Text Domain:       spectra-demo-importer 
**/

add_action('init', 'spectra_demo_importer_check_activation_redirect');

function spectra_demo_importer_check_activation_redirect() {
  if (is_admin() && get_option('spectra_demo_importer_plugin_activated', false)) {
    delete_option('spectra_demo_importer_plugin_activated');
    wp_safe_redirect(admin_url('admin.php?page=spectrademoimporter-wizard'));
    exit;
  }
}

register_activation_hook(__FILE__, 'spectra_demo_importer_activate');

function spectra_demo_importer_activate() {
    add_option('spectra_demo_importer_plugin_activated', true);
}

// License verification constant
define( 'SEDI_SECRET_KEY', '65e43d97f3eca3.41814020' );
define( 'SEDI_FILE', __FILE__ );
define( 'SEDI_BASE', plugin_basename( SEDI_FILE ) );
define( 'SEDI_DIR', plugin_dir_path( SEDI_FILE ) );
define( 'SEDI_URL', plugins_url( '/', SEDI_FILE ) );
define( 'SEDI_ADMIN_CUSTOM_ENDPOINT', 'https://spectrathemes.com/wp-json/spectra-importer-admin/v2/' );
define( 'SPECTRA_THEMES_HOME_URL', "https://spectrathemes.com" );

if( ! function_exists('get_plugin_data') ) {
  require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

$plugin_data = get_plugin_data( __FILE__ );
define( 'SEDI_VER', $plugin_data['Version'] );

require SEDI_DIR .'theme-wizard/config.php';
